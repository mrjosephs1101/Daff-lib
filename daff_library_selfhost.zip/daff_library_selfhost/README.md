# DAFF Library — self-hosted

A small Flask app + SQLite database that lets anyone who can reach it
upload `.daff` files, browse the library, and download files others
uploaded — no claude.ai account, no sign-in, no third-party service.

## Files

- `app.py` — the backend (Flask + SQLite)
- `index.html` — the front end (served by `app.py`)
- `requirements.txt` — just Flask
- `uploads/` — where uploaded `.daff` files land on disk
- `library.db` — the SQLite database (created automatically on first run)

## Run it locally

```
pip install -r requirements.txt
python3 app.py
```

Then open **http://localhost:5000**. That's it — upload a `.daff` file
from the "Add a .daff file" box, and it shows up in the library below,
downloadable by title.

This works on anything that can run Python: a laptop, a Raspberry Pi,
or a Chromebook with Linux (Crostini) turned on. On a plain school
Chromebook without a Linux environment, you won't be able to run the
server itself on the device — see the hosting options below instead.

## Making it reachable by other people

Running it on `localhost` only works for you, on that machine. To let
other people (classmates, friends) actually use it, the server needs
to be reachable by them. A few options, roughly in order of effort:

1. **Same Wi-Fi network** — run `python3 app.py`, find your machine's
   local IP address (e.g. `192.168.1.23`), and others on the same
   network can open `http://192.168.1.23:5000`. No deployment needed,
   but only works while your machine is on and everyone's on the same
   network.

2. **A small always-on free host** — services like Render, Railway,
   Fly.io, or PythonAnywhere can run a small Flask app for free or
   very cheap. The general shape is always: push this folder to a Git
   repo, connect that repo to the host, tell it to run
   `python3 app.py` (or `gunicorn app:app` for a real production
   server instead of Flask's built-in dev server), and it gives you a
   public URL. Exact steps and free-tier limits vary and change over
   time, so check the host's current docs when you pick one.

3. **Your own server/VPS** — if you already have one, copy this
   folder over, install the requirements, and run it behind a real
   web server (nginx + gunicorn) rather than `python3 app.py`
   directly, since Flask says so itself when it starts up.

## Notes

- **No authentication.** Anyone who can reach the server can upload,
  download, and delete. Fine for a private network or a small trusted
  group; add a login before putting this on the open internet.
- **Upload size cap** is set to 250 MB in `app.py`
  (`MAX_CONTENT_LENGTH`) — raise or lower it there if you need to.
- **Real audio files**, unlike the claude.ai-hosted version of this
  library, aren't limited to ~15 MB here — you're storing actual bytes
  on disk, not working around a text-only storage quota.
