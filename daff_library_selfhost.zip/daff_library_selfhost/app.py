#!/usr/bin/env python3
"""
app.py - self-hostable DAFF library backend.

A small Flask app backed by a real SQLite database. Stores uploaded
.daff files on disk and their details in the database; serves the
front end (index.html) and a JSON API for it to talk to.

Run locally:
    pip install flask
    python3 app.py
    -> open http://localhost:5000

No login/accounts - anyone who can reach this server can upload,
browse, and download. Fine on a home network or for a small group of
friends; put it behind real authentication before exposing it to the
open internet.
"""

import os
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, request, jsonify, send_from_directory, send_file, abort, g

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
DB_PATH = BASE_DIR / "library.db"
UPLOAD_DIR.mkdir(exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 250 * 1024 * 1024  # 250 MB per upload, adjust as needed


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS library (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            artist TEXT,
            album TEXT,
            stage_count INTEGER DEFAULT 0,
            size_bytes INTEGER DEFAULT 0,
            filename TEXT NOT NULL,
            uploaded_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


# ---- static front end ----

@app.route("/")
def index():
    return send_from_directory(BASE_DIR, "index.html")


# ---- API ----

@app.route("/api/library", methods=["GET"])
def list_library():
    db = get_db()
    rows = db.execute(
        "SELECT id, title, artist, album, stage_count, size_bytes, uploaded_at "
        "FROM library ORDER BY uploaded_at DESC"
    ).fetchall()
    return jsonify([dict(r) for r in rows])


@app.route("/api/upload", methods=["POST"])
def upload():
    file = request.files.get("daff")
    title = (request.form.get("title") or "").strip()
    artist = (request.form.get("artist") or "").strip()
    album = (request.form.get("album") or "").strip()
    stage_count = request.form.get("stage_count", type=int) or 0

    if not file or not title:
        return jsonify({"error": "a .daff file and a title are required"}), 400

    header = file.read(4)
    if header != b"DAFF":
        return jsonify({"error": "that doesn't look like a .daff file (bad magic header)"}), 400
    file.seek(0)

    stored_name = f"{uuid.uuid4().hex}.daff"
    dest_path = UPLOAD_DIR / stored_name
    file.save(dest_path)
    size_bytes = dest_path.stat().st_size

    db = get_db()
    cur = db.execute(
        "INSERT INTO library (title, artist, album, stage_count, size_bytes, filename, uploaded_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (title, artist, album, stage_count, size_bytes, stored_name,
         datetime.now(timezone.utc).isoformat(timespec="seconds")),
    )
    db.commit()
    return jsonify({"id": cur.lastrowid}), 201


@app.route("/api/download/<int:entry_id>", methods=["GET"])
def download(entry_id):
    db = get_db()
    row = db.execute("SELECT * FROM library WHERE id = ?", (entry_id,)).fetchone()
    if row is None:
        abort(404)
    file_path = UPLOAD_DIR / row["filename"]
    if not file_path.exists():
        abort(404)
    safe_title = "".join(c for c in row["title"] if c.isalnum() or c in " _-") or "output"
    return send_file(file_path, as_attachment=True, download_name=f"{safe_title}.daff")


@app.route("/api/library/<int:entry_id>", methods=["DELETE"])
def delete_entry(entry_id):
    db = get_db()
    row = db.execute("SELECT * FROM library WHERE id = ?", (entry_id,)).fetchone()
    if row is None:
        abort(404)
    file_path = UPLOAD_DIR / row["filename"]
    if file_path.exists():
        file_path.unlink()
    db.execute("DELETE FROM library WHERE id = ?", (entry_id,))
    db.commit()
    return jsonify({"deleted": True})


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)
